import os

class Config:
    SQLALCHEMY_DATABASE_URI = "postgresql://postgres:cantares2025.@db.zwmizphrwirvggmbkumm.supabase.co:5432/postgres"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = "supersecreto"